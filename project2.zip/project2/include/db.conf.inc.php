<?php

    $dbHost = 'localhost';
    $dbUser = 'tictactoe';
    $dbPass = 'project2';
    $use    = 'tictactoe';
    
?>