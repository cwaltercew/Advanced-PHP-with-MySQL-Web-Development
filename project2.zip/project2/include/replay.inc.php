<?php

function getWinner($id) {
    
    require('include/db.conf.inc.php');
    
    $db = new mysqli($dbHost, $dbUser, $dbPass, $use);
    $sql = "SELECT result FROM games WHERE id = ?";
        
    $stmt = new mysqli_stmt($db, $sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    
    $stmt->bind_result($winner);
    $stmt->fetch();
    
    $stmt->close;
    $db->close();
    
    return $winner;
}

function getMaxMoves($id) {
    
    require('include/db.conf.inc.php');
    
    $db = new mysqli($dbHost, $dbUser, $dbPass, $use);
    $sql = "SELECT COUNT(*) FROM moves WHERE game_id= ?";
        
    $stmt = $db->prepare($sql);
    $stmt->bind_param('i', $id);
    $stmt->execute();
    
    $stmt->bind_result($maxMoves);
    $stmt->fetch();
    
    $stmt->close;
    $db->close();
    
    return $maxMoves;
}

function getGameName($id) {
    
    require('include/db.conf.inc.php');
    
    $db = new mysqli($dbHost, $dbUser, $dbPass, $use);
    $sql = "SELECT name FROM games WHERE id = ?";
        
    $stmt = new mysqli_stmt($db, $sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    
    $stmt->bind_result($name);
    $stmt->fetch();
    
    $stmt->close;
    $db->close();
    
    return $name;
}

function getGameID($name) {
    
    require('include/db.conf.inc.php');
    
    $db = new mysqli($dbHost, $dbUser, $dbPass, $use);
    $sql = "SELECT id FROM games WHERE name = ?";
        
    $stmt = new mysqli_stmt($db, $sql);
    $stmt->bind_param("s", $name);
    $stmt->execute();
    
    $stmt->bind_result($id);
    $stmt->fetch();
    
    $stmt->close;
    $db->close();
    
    return $id;
}

function getBoard($id, $move)
{
    require('include/db.conf.inc.php');
    
    $board = array('','','','','','','','','');
    $db = new mysqli($dbHost, $dbUser, $dbPass, $use);
    
    $sql = "SELECT square, player FROM moves WHERE game_id = ? AND move_num <= ? ORDER BY square";
        
    $stmt = new mysqli_stmt($db, $sql);
    $stmt->bind_param('ii', $id, $move);
    $stmt->execute();
    $stmt->bind_result($square, $player);
    while($row = $stmt->fetch()) {
        $board[$square] = $player;
    }
    
    $stmt->close;
    $db->close();
    
    return $board;
}

function DrawBoard($gBoard)
{
    
    define("X_IMAGE", "images/X.gif");
    define("O_IMAGE", "images/O.gif");

    // Start the table
    print '<table border=0 cellpadding=0 cellspacing=0>';

    $iLoop = 0;
    for($iRow = 0; $iRow < 5; $iRow++)
    {
        print "<tr>\n";
        for($iCol = 0; $iCol < 5; $iCol++)
        {
            if($iRow == 1 || $iRow == 3)
            {
                print "<td width=\"12\" height=\"5\" align=\"center\" valign=\"middle\" bgcolor=\"#000000\">&nbsp;</td>\n";
            }
            else
            {
                if($iCol == 1 || $iCol == 3)
                {
                    print "<td width=\"12\" height=\"115\" align=\"center\" valign=\"middle\" bgcolor=\"#000000\">&nbsp;</td>\n";
                }
                else
                {
                    print "<td width=\"115\" height=\"115\" align=\"center\" valign=\"middle\">";

                    if($gBoard[$iLoop] == "X")
                    {
                        print '<img src="'. X_IMAGE .'">';
                    }
                    elseif($gBoard[$iLoop] == "O")
                    {
                        print '<img src="'. O_IMAGE .'">';
                    }

                    print "</td>\n";
                    $iLoop++;
                }
            }
            
        }
        print "</tr>\n";
    }

    // End the table
    print "</table>";
}
?>