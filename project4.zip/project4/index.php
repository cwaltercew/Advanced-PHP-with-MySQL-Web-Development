<?php

require_once('header.php');

guestbook_start_page('Welcome to Guestbook 2000!');

?>

<p><br></p>
<p><br></p>

<?php

guestbook_end_page();

?>
