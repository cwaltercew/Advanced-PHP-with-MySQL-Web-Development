<?php

  $db_host = "itins3.matcmadison.edu";
  $db_user = "nstier";
  $db_pass = "s2633583";
  $db_name = "nstier";
  
?>