<p align="center">
  You are logged in as user: <b><? echo $user['user_name']; ?></b> 
  </p>
