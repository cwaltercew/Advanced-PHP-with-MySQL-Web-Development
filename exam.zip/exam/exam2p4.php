<?php
  require('exam2p4db.inc.php');
  // Adv.PHP MySQL exam 2 - Fall 2010 - problem 4 (15 pts.)
  //
  // This script contains the PHP code to get a last name, first name and
  // phone number from the HTML form phonInsert.html.
  //
  // You are to modify the code to insert the values that are stored in the 
  // PHP variables $surname, $firstname and $phone into the table phonebook
  // in the MySQL database on the class server that is the same as your MySQL
  // username.
  // Note 1: Use the "mysqli" library of functions for this problem.
  // Note 2: The phonebook table may already exist in your database. But, if
  //         not, you should create this table using the following SQL statement:
  //
  //         CREATE TABLE phonebook (
  //           phonebook_id int(6) NOT NULL auto_increment,
  //           surname VARCHAR(50) NOT NULL,
  //           firstname VARCHAR(50) NOT NULL,
  //           phone VARCHAR(20) NOT NULL,
  //           PRIMARY KEY (phonebook_id)
  //         ) type=MyISAM ;
  //
  // Task: Add code to connect to MySQL on the class server,
  //       itins3.matcmadison.edu and use the MySQL database that matches
  //       your username.
  //       Along with this file, you will need the following files from
  //       Blackboard:
  //                      exam2p4db.inc.php
  //                      exam2p4phonInsert.html
  //                      exam2p4phonReceipt.php
  //
  // Student Name:
  // Date of Exam: December 2010
  //
  // Submit your finished scripts (all files even if you did not
  // modify them) using the Blackboard project submission procedure.
  //
  // This code tests for user input
  if (!empty($_GET["surname"]) &&
      !empty($_GET["firstname"]) &&
      !empty($_GET["phone"]))
  {
    // Connect to MySQL on host itins3.matcmadison.edu with your user name
    // and password. Use the variables from the exam2p3db.inc.php file rather
    // than hardcoding values.
    // Give an error message and exit if connection to the database fails.
    $connection = new mysqli($hostname, $username, $password, $databasename);
    if (mysqli_connect_errno()) {
      printf("Connect failed: %s\n", mysqli_connect_error());
      exit();
    }
    
    // Use the database (schema) that matches your username on the class server.

    // Remove special characters from the input
    // You should check that the mysqliclean() function (in exam2p3db.inc.php)
    // escapes user input adequately before it is saved to the database.
    $surname = mysqliclean($connection, $_GET, "surname", 50);
    $firstname = mysqliclean($connection, $_GET, "firstname", 50);
    $phone = mysqliclean($connection, $_GET, "phone", 20);

    // This statement creates the query in variable $query to insert  
    // a row into the phonebook table.
    // You need to change it to use "prepare" syntax:
    $query = "INSERT INTO phonebook (phonebook_id, surname, firstname, phone) VALUES (NULL, ?, ?, ?)";
    $result = new mysqli_stmt($connection, $query);
    $result->bind_param('sss', $surname, $firstname, $phone);
    // Add the statement to execute the INSERT in the parentheses
    if ($result->execute())
    {
      // This statement calls the header() function with location
      // of the exam2p4phonReceipt.php file, setting a status of "T"
      // and passing the phonebook_id value.
      header("Location: exam2p4phonReceipt.php?status=T&" .
             "phonebook_id=". mysqli_insert_id($connection));
      exit;
    }
  } 
  // If any of the form fields are empty, send a status of "F" to
  // file exam2p4phonReceipt.php 
  header("Location: exam2p4phonReceipt.php?status=F");
?>
