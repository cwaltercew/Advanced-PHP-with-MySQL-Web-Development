<?php
  // Adv.PHP MySQL exam 2 - Fall 2010 - problem 2
  // This include file contains DB variables for use in your problem 2 script.
  // Note that you have been given "read-only" access to the winestore database
  // schema on the class server, itins3 .
  //
   $hostname = "itins3.matcmadison.edu";
   $databasename = "winestore";
   $username = "nstier";
   $password = "s2633583";

?>
