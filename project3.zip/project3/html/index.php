<?php # Script: index.php
// This is the main page for the site.

// Set the page title and include the HTML header.
$page_title = 'Make an Impression!';
include_once ('includes/header.html');
?>

<p align=center>
Welcome to our site, please use the links above
to select prints for purchase.
</p><p align=center>
Thank you for visiting our site, hope we make a good impression!</p>

<?php // Include the HTML footer file.
include_once ('includes/footer.html');
?>